<?php

use App\Http\Controllers\BusySyncController;
use Illuminate\Support\Facades\Route;

Route::get('/busy/sync/parties', [BusySyncController::class, 'parties']);
Route::get('/busy/sync/products', [BusySyncController::class, 'products']);
Route::get('/busy/sync/units', [BusySyncController::class, 'units']);